-- queue schema
INSERT INTO rfrnc_que_work_phase
(
  QUE_WORK_PHASE_ID,
  QUE_WORK_PHASE_NAME,
  QUE_WORK_PHASE_DESC
)
VALUES
(
  '290',
  'Error',
  'Error happened in process'
); 