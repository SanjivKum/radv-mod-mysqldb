-- intake schema
INSERT INTO rfrnc_work_stp_cmt_type
(
  WORK_STP_CMT_TYPE_ID,
  WORK_STP_CMT_TYPE_NAME,
  WORK_STP_CMT_TYPE_DESC
)
VALUES
(
  '1',
  'General',
  'General Comment'
);