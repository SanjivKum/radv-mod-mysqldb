use cdat_dev_queue;

delete from org_que_work_stp;

INSERT INTO `org_que_work_stp`
(`ORG_QUE_WORK_STP_ID`,
`ORG_ID`,
`QUE_WORK_STP_ID`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(1,
101,
1,
now(),
null,
null,
null);

INSERT INTO `org_que_work_stp`
(`ORG_QUE_WORK_STP_ID`,
`ORG_ID`,
`QUE_WORK_STP_ID`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(2,
101,
2,
now(),
null,
null,
null);

INSERT INTO `org_que_work_stp`
(`ORG_QUE_WORK_STP_ID`,
`ORG_ID`,
`QUE_WORK_STP_ID`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(3,
101,
3,
now(),
null,
null,
null);

INSERT INTO `org_que_work_stp`
(`ORG_QUE_WORK_STP_ID`,
`ORG_ID`,
`QUE_WORK_STP_ID`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(4,
101,
4,
now(),
null,
null,
null);

INSERT INTO `org_que_work_stp`
(`ORG_QUE_WORK_STP_ID`,
`ORG_ID`,
`QUE_WORK_STP_ID`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(5,
102,
5,
now(),
null,
null,
null);