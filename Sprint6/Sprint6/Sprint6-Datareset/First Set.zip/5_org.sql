use cdat_dev_user;

INSERT INTO `org`
(`ORG_ID`,
`ORG_TYPE_ID`,
`ORG_NAME`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(101,
1,
'MRRC Org 02',
now(),
null,
null,
null);

INSERT INTO `org`
(`ORG_ID`,
`ORG_TYPE_ID`,
`ORG_NAME`,
`CREATD_DT`,
`CREATD_BY`,
`MDFYD_DT`,
`MDFYD_BY`)
VALUES
(102,
1,
'MRRC Org 03',
now(),
null,
null,
null);