use cdat_qa_config;

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('130', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('130', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('131', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('131', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('132', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('132', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('133', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('133', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('134', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('134', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('135', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('135', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('136', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('136', '2', '1');

INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('137', '1', '1');
INSERT INTO `user_smpl` (`USER_ID`, `SMPL_ID`, `ACTV_IND`) VALUES ('137', '2', '1');