use cdat_qa_user;

INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('130', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('131', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('132', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('133', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('134', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('135', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('136', '101', '1');
INSERT INTO `user_org` (`USER_ID`, `ORG_ID`, `ACTV_IND`) VALUES ('137', '101', '1');
