use cdat_qa_user;

update user set enabled = 1 where user_id in (130, 131, 132, 133, 134, 135, 136, 137);