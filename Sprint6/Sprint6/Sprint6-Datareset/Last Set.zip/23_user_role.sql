use cdat_qa_user;

-- mrrc2-user# users all get Submission Review role
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '130');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '131');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '132');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '133');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '134');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '135');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '136');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('14', '137');

-- mrrc2-user# users all get Senior Evaluation role
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '130');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '131');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '132');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '133');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '134');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '135');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '136');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('15', '137');

-- mrrc2-user# users all get Invalid Confirmation role
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '130');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '131');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '132');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '133');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '134');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '135');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '136');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('16', '137');

-- mrrc2-user# users all get Focused Review role
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '130');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '131');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '132');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '133');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '134');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '135');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '136');
INSERT INTO `user_role` (`ROLE_ID`, `USER_ID`) VALUES ('48', '137');
